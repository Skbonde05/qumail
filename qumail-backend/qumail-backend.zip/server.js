// server.js - QUMAIL INDEPENDENT PLATFORM BACKEND WITH QUANTUM ENCRYPTION

// Load environment variables from .env file
const path = require('path');
const fs = require('fs');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { body, validationResult } = require('express-validator');
const crypto = require('crypto');
const mongoose = require('mongoose');
const multer = require('multer');

const app = express();

// Configure CORS properly
app.use(cors({
  origin: process.env.CORS_ORIGIN || '*',
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization']
}));

// =============== CRITICAL: INCREASE PAYLOAD LIMIT ===============
app.use(express.json({ limit: '10mb' }));  // Increase from default 100kb to 10MB
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
// ================================================================

const PORT = process.env.PORT || 5000;
const JWT_SECRET = process.env.JWT_SECRET || 'qumail-quantum-secure-key-2024';
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;

// Validate environment variables
console.log('🔧 Environment Configuration:');
console.log(`   PORT: ${PORT}`);
console.log(`   JWT_SECRET: ${JWT_SECRET ? '✓ Set' : '✗ Using default (insecure for production!)'}`);
console.log(`   NODE_ENV: ${process.env.NODE_ENV || 'development'}`);
console.log(`   BASE_URL: ${BASE_URL}`);

if (!process.env.JWT_SECRET && process.env.NODE_ENV === 'production') {
  console.error('⚠️  WARNING: JWT_SECRET not set in production environment!');
  console.error('⚠️  Please set JWT_SECRET in your .env file for security.');
}

// ================== MONGODB CONNECTION ==================
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/qumail';

mongoose.connect(MONGODB_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
  .then(() => {
    console.log('✅ MongoDB connected successfully');
  })
  .catch((err) => {
    console.error('❌ MongoDB connection error:', err.message);
  });

const isMongoConnected = () => {
  return mongoose.connection.readyState === 1;
};

// ================== MONGODB MODELS ==================
const userSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  password: {
    type: String,
    required: true
  },
  avatar: {
    type: String,
    default: ''
  },
  settings: {
    emailNotifications: {
      type: Boolean,
      default: true
    },
    autoSaveDrafts: {
      type: Boolean,
      default: true
    },
    signature: {
      type: String,
      default: ''
    },
    twoFactorEnabled: {
      type: Boolean,
      default: false
    },
    language: {
      type: String,
      default: 'en'
    },
    timezone: {
      type: String,
      default: 'UTC'
    }
  },
  encryptionKeys: {
    otp: { type: String, default: null },
    aes256: { type: String, default: null }
  },
  storageUsed: {
    type: Number,
    default: 0
  },
  storageLimit: {
    type: Number,
    default: 10 * 1024 * 1024 * 1024 // 10GB
  },
  isVerified: {
    type: Boolean,
    default: false
  },
  role: {
    type: String,
    enum: ['user', 'admin', 'moderator'],
    default: 'user'
  },
  lastLogin: {
    type: Date,
    default: null
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

userSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

const User = mongoose.model('User', userSchema);

// Mail Schema
const mailSchema = new mongoose.Schema({
  mailId: {
    type: String,
    required: true,
    unique: false // Changed from true - multiple users can have same mailId
  },
  from: {
    type: String,
    required: true,
    lowercase: true,
    trim: true
  },
  to: {
    type: String,
    required: true,
    lowercase: true,
    trim: true
  },
  subject: {
    type: String,
    required: true,
    default: "(No Subject)"
  },
  body: {
    type: String,
    required: true
  },
  encryption: {
    type: String,
    enum: ["NONE", "OTP", "AES"],
    default: "NONE"
  },
  aesKey: {
    type: String,
    default: null
  },
  aesIV: {
    type: String,
    default: null
  },
  folder: {
    type: String,
    enum: ["INBOX", "SENT", "ARCHIVE"],
    required: true
  },
  owner: {
    type: String,
    required: true,
    lowercase: true,
    trim: true
  },
  read: {
    type: Boolean,
    default: false
  },
  starred: {
    type: Boolean,
    default: false
  },
  important: {
    type: Boolean,
    default: false
  },
  trash: {
    type: Boolean,
    default: false
  },
  snoozed: {
    type: Date,
    default: null
  },
  labels: [{
    type: String,
    default: []
  }],
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Compound index for mailId + owner to ensure uniqueness per user
mailSchema.index({ mailId: 1, owner: 1 }, { unique: true });

mailSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

const Mail = mongoose.model('Mail', mailSchema);

// ================== HELPER FUNCTIONS ==================

// Validate email is @qumail.com
const validateQumailEmail = (email) => {
  return email.toLowerCase().endsWith('@qumail.com');
};

// Generate JWT token
const generateToken = (user) => {
  return jwt.sign(
    { 
      id: user._id,
      email: user.email,
      name: user.name,
      role: user.role,
      timestamp: Date.now(),
      type: 'qumail'
    },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
};

// Middleware to verify JWT token
const verifyToken = (req, res, next) => {
  try {
    const authHeader = req.headers['authorization'];
    if (!authHeader) {
      return res.status(401).json({
        success: false,
        message: 'No authorization token provided'
      });
    }
    
    const token = authHeader.split(' ')[1];
    if (!token) {
      return res.status(401).json({
        success: false,
        message: 'Invalid token format'
      });
    }
    
    const decoded = jwt.verify(token, JWT_SECRET);
    
    if (decoded.type !== 'qumail') {
      return res.status(401).json({
        success: false,
        message: 'Invalid token type'
      });
    }
    
    req.user = decoded;
    next();
  } catch (error) {
    console.error('Token verification error:', error.message);
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired token'
    });
  }
};

// ================== ENCRYPTION FUNCTIONS ==================

// Generate quantum OTP key
const generateOTPKey = (textLength) => {
  const keyLength = Math.ceil(textLength / 2) * 2;
  return crypto.randomBytes(keyLength).toString('hex');
};

// Generate AES key
const generateAESKey = () => {
  return crypto.randomBytes(32).toString('hex');
};

// Generate AES IV
const generateAESIV = () => {
  return crypto.randomBytes(16).toString('hex');
};

// Validate hex key
const isValidHexKey = (key) => {
  if (!key || typeof key !== 'string') return false;
  return /^[0-9a-fA-F]+$/.test(key);
};

// OTP Encryption
const otpEncrypt = (text, key) => {
  try {
    if (!isValidHexKey(key)) {
      throw new Error('Invalid hex key format for OTP encryption');
    }
    
    const textBuffer = Buffer.from(text, 'utf8');
    const keyBuffer = Buffer.from(key, 'hex');
    
    if (keyBuffer.length < textBuffer.length) {
      throw new Error(`OTP key too short! Key: ${keyBuffer.length} bytes, Text: ${textBuffer.length} bytes`);
    }
    
    const effectiveKey = keyBuffer.slice(0, textBuffer.length);
    const encrypted = Buffer.alloc(textBuffer.length);
    
    for (let i = 0; i < textBuffer.length; i++) {
      encrypted[i] = textBuffer[i] ^ effectiveKey[i];
    }
    
    return encrypted.toString('hex');
  } catch (error) {
    console.error('OTP encryption error:', error);
    throw new Error(`OTP encryption failed: ${error.message}`);
  }
};

// OTP Decryption
const otpDecrypt = (encryptedHex, key) => {
  try {
    if (!isValidHexKey(key)) {
      throw new Error('Invalid hex key format for OTP decryption');
    }
    
    const encryptedBuffer = Buffer.from(encryptedHex, 'hex');
    const keyBuffer = Buffer.from(key, 'hex');
    
    if (keyBuffer.length < encryptedBuffer.length) {
      throw new Error(`OTP key too short! Key: ${keyBuffer.length} bytes, Cipher: ${encryptedBuffer.length} bytes`);
    }
    
    const effectiveKey = keyBuffer.slice(0, encryptedBuffer.length);
    const decrypted = Buffer.alloc(encryptedBuffer.length);
    
    for (let i = 0; i < encryptedBuffer.length; i++) {
      decrypted[i] = encryptedBuffer[i] ^ effectiveKey[i];
    }
    
    return decrypted.toString('utf8');
  } catch (error) {
    console.error('OTP decryption error:', error);
    throw new Error(`OTP decryption failed: ${error.message}`);
  }
};

// AES Encryption (GCM mode)
const aesEncrypt = (text, key, iv) => {
  try {
    const keyBuffer = Buffer.from(key, 'hex');
    const ivBuffer = Buffer.from(iv, 'hex');
    
    const cipher = crypto.createCipheriv('aes-256-gcm', keyBuffer, ivBuffer);
    
    let encrypted = cipher.update(text, 'utf8', 'hex');
    encrypted += cipher.final('hex');
    
    const authTag = cipher.getAuthTag();
    
    return {
      iv: iv,
      content: encrypted,
      authTag: authTag.toString('hex')
    };
  } catch (error) {
    console.error('AES encryption error:', error);
    throw new Error(`AES encryption failed: ${error.message}`);
  }
};

// AES Decryption (GCM mode)
const aesDecrypt = (encryptedData, key) => {
  try {
    const keyBuffer = Buffer.from(key, 'hex');
    const ivBuffer = Buffer.from(encryptedData.iv, 'hex');
    const authTag = Buffer.from(encryptedData.authTag, 'hex');
    
    const decipher = crypto.createDecipheriv('aes-256-gcm', keyBuffer, ivBuffer);
    decipher.setAuthTag(authTag);
    
    let decrypted = decipher.update(encryptedData.content, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    
    return decrypted;
  } catch (error) {
    console.error('AES decryption error:', error);
    throw new Error(`AES decryption failed: ${error.message}`);
  }
};

// Simple AES encryption for Mail model
const encryptAES = (text, key, iv) => {
  try {
    const encryptedData = aesEncrypt(text, key, iv);
    return JSON.stringify(encryptedData);
  } catch (error) {
    throw new Error(`AES encryption failed: ${error.message}`);
  }
};

// Simple AES decryption for Mail model
const decryptAES = (encryptedText, key, iv) => {
  try {
    const encryptedData = JSON.parse(encryptedText);
    return aesDecrypt(encryptedData, key);
  } catch (error) {
    throw new Error(`AES decryption failed: ${error.message}`);
  }
};

// ================== FILE UPLOAD CONFIGURATION ==================
const createUploadsDirectory = () => {
  const uploadsDir = path.join(__dirname, 'uploads');
  const avatarsDir = path.join(__dirname, 'uploads/avatars');
  
  if (!fs.existsSync(uploadsDir)) {
    fs.mkdirSync(uploadsDir, { recursive: true });
    console.log(`📁 Created uploads directory: ${uploadsDir}`);
  }
  
  if (!fs.existsSync(avatarsDir)) {
    fs.mkdirSync(avatarsDir, { recursive: true });
    console.log(`📁 Created avatars directory: ${avatarsDir}`);
  }
};

createUploadsDirectory();

// Configure multer for avatar uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const uploadDir = path.join(__dirname, 'uploads/avatars');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const safeEmail = req.user.email.replace(/[@.]/g, '-').toLowerCase();
    const extension = path.extname(file.originalname).toLowerCase();
    cb(null, safeEmail + '-' + uniqueSuffix + extension);
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // 5MB limit
  },
  fileFilter: function (req, file, cb) {
    const allowedTypes = /jpeg|jpg|png|gif|webp/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);
    
    if (extname && mimetype) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files (jpeg, jpg, png, gif, webp) are allowed'));
    }
  }
});

// Function to get full avatar URL
const getAvatarUrl = (filename) => {
  if (!filename) return '';
  return `${BASE_URL}/uploads/avatars/${filename}`;
};

// ================== ROUTES ==================

// Health check endpoint
app.get('/api/health', async (req, res) => {
  const dbStatus = isMongoConnected() ? 'connected' : 'disconnected';
  
  res.json({
    success: true,
    status: 'healthy',
    timestamp: new Date().toISOString(),
    platform: 'QuMail Quantum Platform',
    environment: process.env.NODE_ENV || 'development',
    database: dbStatus,
    uptime: process.uptime()
  });
});

// Server info
app.get('/', (req, res) => {
  const dbStatus = isMongoConnected() ? 'connected' : 'disconnected';
  
  res.json({ 
    status: 'running', 
    message: 'QuMail Quantum-Secure Email Platform',
    version: '4.1',
    platform: 'Independent Secure Network',
    environment: process.env.NODE_ENV || 'development',
    database: dbStatus,
    baseUrl: BASE_URL,
    endpoints: {
      auth: ['POST /api/register', 'POST /api/login', 'POST /api/logout', 'POST /api/verify-token'],
      email: ['POST /api/send', 'POST /api/mail/inbox', 'POST /api/mail/sent', 'GET /api/mail/:mailId', 'POST /api/decrypt', 'PUT /api/mail/:mailId/status', 'POST /api/mail/batch-update', 'POST /api/mail/move-to-folder', 'POST /api/mail/bulk-actions', 'POST /api/mail/empty-trash'],
      user: ['GET /api/profile', 'PUT /api/profile', 'POST /api/change-password', 'POST /api/upload-avatar', 'DELETE /api/avatar']
    }
  });
});

// ------------------ REGISTRATION ------------------
app.post('/api/register', 
  [
    body('name').trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2-50 characters'),
    body('email').isEmail().withMessage('Valid email required').custom(validateQumailEmail).withMessage('Only @qumail.com addresses allowed'),
    body('password').isLength({ min: 12 }).withMessage('Password must be at least 12 characters'),
    body('confirmPassword').custom((value, { req }) => value === req.body.password).withMessage('Passwords do not match')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: errors.array()
        });
      }
      
      const { name, email, password } = req.body;
      const lowerEmail = email.toLowerCase();
      
      console.log('📝 Registration attempt for:', lowerEmail);
      
      // Check if user already exists
      const existingUser = await User.findOne({ email: lowerEmail });
      if (existingUser) {
        return res.status(400).json({
          success: false,
          message: 'User with this @qumail.com address already exists'
        });
      }
      
      // Hash password
      const salt = await bcrypt.genSalt(12);
      const hashedPassword = await bcrypt.hash(password, salt);
      
      // Generate encryption keys
      const otpKey = generateOTPKey(256);
      const aesKey = generateAESKey();
      
      // Create user
      const user = await User.create({
        name: name.trim(),
        email: lowerEmail,
        password: hashedPassword,
        encryptionKeys: {
          otp: otpKey,
          aes256: aesKey
        }
      });
      
      // Generate token
      const token = generateToken(user);
      
      console.log(`✅ User registered: ${lowerEmail} (${name})`);
      
      res.status(201).json({
        success: true,
        message: 'Welcome to QuMail Quantum-Secure Email Platform!',
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          avatar: user.avatar,
          createdAt: user.createdAt,
          settings: user.settings
        },
        token: token
      });
      
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({
        success: false,
        message: 'Internal server error during registration'
      });
    }
  }
);

// ------------------ LOGIN ------------------
app.post('/api/login',
  [
    body('email').isEmail().withMessage('Valid email required').custom(validateQumailEmail).withMessage('Only @qumail.com addresses allowed'),
    body('password').notEmpty().withMessage('Password required')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: errors.array()
        });
      }
      
      const { email, password } = req.body;
      const lowerEmail = email.toLowerCase();
      
      console.log('🔐 Login attempt for:', lowerEmail);
      
      // Find user
      const user = await User.findOne({ email: lowerEmail });
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'No account found with this @qumail.com address'
        });
      }
      
      // Verify password
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({
          success: false,
          message: 'Invalid password'
        });
      }
      
      // Update last login
      user.lastLogin = new Date();
      await user.save();
      
      // Generate token
      const token = generateToken(user);
      
      console.log(`✅ Login successful: ${lowerEmail}`);
      
      // Get email counts for response
      const [inboxCount, sentCount, archiveCount, trashCount] = await Promise.all([
        Mail.countDocuments({ owner: lowerEmail, folder: 'INBOX', trash: false }),
        Mail.countDocuments({ owner: lowerEmail, folder: 'SENT', trash: false }),
        Mail.countDocuments({ owner: lowerEmail, folder: 'ARCHIVE', trash: false }),
        Mail.countDocuments({ owner: lowerEmail, trash: true })
      ]);
      
      res.json({
        success: true,
        message: `Welcome back to QuMail, ${user.name}!`,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          avatar: user.avatar,
          settings: user.settings,
          storageUsed: user.storageUsed,
          storageLimit: user.storageLimit,
          isVerified: user.isVerified,
          role: user.role,
          createdAt: user.createdAt,
          lastLogin: user.lastLogin
        },
        token: token,
        folderCounts: {
          inbox: inboxCount,
          sent: sentCount,
          archive: archiveCount,
          trash: trashCount
        }
      });
      
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({
        success: false,
        message: 'Internal server error during authentication'
      });
    }
  }
);

// ------------------ VERIFY TOKEN ------------------
app.post('/api/verify-token', verifyToken, async (req, res) => {
  try {
    const user = await User.findOne({ email: req.user.email });
    if (!user) {
      return res.status(401).json({
        success: false,
        valid: false,
        message: 'User not found'
      });
    }
    
    // Get email counts
    const [inboxCount, sentCount, archiveCount, trashCount] = await Promise.all([
      Mail.countDocuments({ owner: req.user.email, folder: 'INBOX', trash: false }),
      Mail.countDocuments({ owner: req.user.email, folder: 'SENT', trash: false }),
      Mail.countDocuments({ owner: req.user.email, folder: 'ARCHIVE', trash: false }),
      Mail.countDocuments({ owner: req.user.email, trash: true })
    ]);
    
    res.json({
      success: true,
      valid: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        settings: user.settings,
        storageUsed: user.storageUsed,
        storageLimit: user.storageLimit,
        isVerified: user.isVerified,
        role: user.role,
        createdAt: user.createdAt,
        lastLogin: user.lastLogin
      },
      folderCounts: {
        inbox: inboxCount,
        sent: sentCount,
        archive: archiveCount,
        trash: trashCount
      }
    });
  } catch (error) {
    res.status(401).json({
      success: false,
      valid: false,
      message: 'Invalid token'
    });
  }
});

// ================== PROFILE ROUTES ==================

// ------------------ GET USER PROFILE ------------------
app.get('/api/profile', verifyToken, async (req, res) => {
  try {
    const user = await User.findOne({ email: req.user.email });
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    // Get email counts
    const [inboxCount, sentCount, archiveCount, trashCount] = await Promise.all([
      Mail.countDocuments({ owner: req.user.email, folder: 'INBOX', trash: false }),
      Mail.countDocuments({ owner: req.user.email, folder: 'SENT', trash: false }),
      Mail.countDocuments({ owner: req.user.email, folder: 'ARCHIVE', trash: false }),
      Mail.countDocuments({ owner: req.user.email, trash: true })
    ]);
    
    // Calculate storage percentage
    const storagePercentage = user.storageLimit > 0 
      ? (user.storageUsed / user.storageLimit) * 100 
      : 0;
    
    res.json({
      success: true,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar,
        settings: user.settings,
        storageUsed: user.storageUsed,
        storageLimit: user.storageLimit,
        storagePercentage: storagePercentage,
        isVerified: user.isVerified,
        role: user.role,
        createdAt: user.createdAt,
        lastLogin: user.lastLogin,
        updatedAt: user.updatedAt
      },
      encryption: {
        hasOTPKey: !!user.encryptionKeys?.otp,
        hasAESKey: !!user.encryptionKeys?.aes256
      },
      folderCounts: {
        inbox: inboxCount,
        sent: sentCount,
        archive: archiveCount,
        trash: trashCount
      }
    });
    
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// ------------------ UPDATE USER PROFILE ------------------
app.put('/api/profile', 
  [
    verifyToken,
    body('name').optional().trim().isLength({ min: 2, max: 50 }).withMessage('Name must be 2-50 characters'),
    body('settings.emailNotifications').optional().isBoolean().withMessage('Email notifications must be boolean'),
    body('settings.autoSaveDrafts').optional().isBoolean().withMessage('Auto-save drafts must be boolean'),
    body('settings.signature').optional().trim().isLength({ max: 1000 }).withMessage('Signature too long'),
    body('settings.twoFactorEnabled').optional().isBoolean().withMessage('Two-factor enabled must be boolean'),
    body('settings.timezone').optional().isIn(['UTC', 'America/New_York', 'America/Chicago', 'America/Denver', 'America/Los_Angeles', 'Europe/London', 'Europe/Paris', 'Asia/Tokyo', 'Asia/Kolkata']).withMessage('Invalid timezone')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: errors.array()
        });
      }
      
      const { name, settings } = req.body;
      const userEmail = req.user.email;
      
      console.log(`📝 Updating profile for: ${userEmail}`);
      
      // Find user
      const user = await User.findOne({ email: userEmail });
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }
      
      // Update fields
      const updates = {};
      if (name) {
        updates.name = name.trim();
      }
      
      if (settings) {
        updates.settings = {
          ...user.settings,
          ...settings
        };
      }
      
      // Apply updates
      Object.assign(user, updates);
      await user.save();
      
      res.json({
        success: true,
        message: 'Profile updated successfully',
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          avatar: user.avatar,
          settings: user.settings,
          storageUsed: user.storageUsed,
          storageLimit: user.storageLimit,
          isVerified: user.isVerified,
          role: user.role,
          createdAt: user.createdAt,
          lastLogin: user.lastLogin,
          updatedAt: user.updatedAt
        }
      });
      
    } catch (error) {
      console.error('Update profile error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to update profile'
      });
    }
  }
);

// ------------------ CHANGE PASSWORD ------------------
app.post('/api/change-password',
  [
    verifyToken,
    body('currentPassword').notEmpty().withMessage('Current password is required'),
    body('newPassword').isLength({ min: 12 }).withMessage('New password must be at least 12 characters'),
    body('confirmPassword').custom((value, { req }) => value === req.body.newPassword).withMessage('Passwords do not match')
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: errors.array()
        });
      }
      
      const { currentPassword, newPassword } = req.body;
      const userEmail = req.user.email;
      
      console.log(`🔐 Changing password for: ${userEmail}`);
      
      // Find user
      const user = await User.findOne({ email: userEmail });
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }
      
      // Verify current password
      const isValidPassword = await bcrypt.compare(currentPassword, user.password);
      if (!isValidPassword) {
        return res.status(401).json({
          success: false,
          message: 'Current password is incorrect'
        });
      }
      
      // Hash new password
      const salt = await bcrypt.genSalt(12);
      const hashedPassword = await bcrypt.hash(newPassword, salt);
      
      // Update password
      user.password = hashedPassword;
      await user.save();
      
      // Generate new token with updated info
      const token = generateToken(user);
      
      res.json({
        success: true,
        message: 'Password changed successfully',
        token: token
      });
      
    } catch (error) {
      console.error('Change password error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to change password'
      });
    }
  }
);

// ------------------ UPLOAD AVATAR (CORRECTED) ------------------
app.post('/api/upload-avatar', 
  verifyToken,
  async (req, res) => {
    try {
      const { avatar } = req.body;
      
      if (!avatar) {
        return res.status(400).json({
          success: false,
          message: 'Avatar data is required'
        });
      }
      
      const userEmail = req.user.email;
      
      console.log(`📷 Uploading avatar for: ${userEmail}`);
      console.log(`   Avatar data length: ${avatar.length} characters`);
      
      // Find user
      const user = await User.findOne({ email: userEmail });
      if (!user) {
        return res.status(404).json({
          success: false,
          message: 'User not found'
        });
      }
      
      // Store Base64 avatar in MongoDB
      user.avatar = avatar;
      await user.save();
      
      console.log(`✅ Avatar stored in MongoDB for: ${userEmail}`);
      
      res.json({
        success: true,
        message: 'Avatar uploaded successfully',
        avatar: user.avatar,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          avatar: user.avatar
        }
      });
      
    } catch (error) {
      console.error('Upload avatar error:', error);
      res.status(500).json({
        success: false,
        message: error.message || 'Failed to upload avatar'
      });
    }
  }
);

// Serve uploaded files statically
app.use('/uploads/avatars', express.static(path.join(__dirname, 'uploads/avatars')));

// ------------------ DELETE AVATAR ------------------
app.delete('/api/avatar', verifyToken, async (req, res) => {
  try {
    const userEmail = req.user.email;
    
    console.log(`🗑️  Deleting avatar for: ${userEmail}`);
    
    // Find user
    const user = await User.findOne({ email: userEmail });
    if (!user) {
      return res.status(404).json({
        success: false,
        message: 'User not found'
      });
    }
    
    // Clear avatar field in database
    user.avatar = '';
    await user.save();
    
    res.json({
      success: true,
      message: 'Avatar deleted successfully',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        avatar: user.avatar
      }
    });
    
  } catch (error) {
    console.error('Delete avatar error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to delete avatar'
    });
  }
});

// ------------------ SEND EMAIL (FIXED - SAME mailId) ------------------
app.post('/api/send', 
  [
    verifyToken,
    body('to').isEmail().withMessage('Valid recipient email required').custom(validateQumailEmail).withMessage('Can only send to @qumail.com addresses'),
    body('subject').optional().trim().isLength({ max: 200 }).withMessage('Subject too long'),
    body('body').trim().notEmpty().withMessage('Message body is required'),
    body('encryptionLevel').optional().isIn(['none', 'otp', 'aes256']).withMessage('Invalid encryption level. Use: none, otp, or aes256')
  ],
  async (req, res) => {
    const session = await mongoose.startSession();
    session.startTransaction();
    
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        await session.abortTransaction();
        return res.status(400).json({
          success: false,
          message: 'Validation failed',
          errors: errors.array()
        });
      }
      
      const { to, subject, body, encryptionLevel = 'none' } = req.body;
      const from = req.user.email;
      
      console.log(`📧 Sending email from ${from} to ${to} with encryption: ${encryptionLevel}`);
      
      // Check if recipient exists
      const lowerTo = to.toLowerCase();
      const recipient = await User.findOne({ email: lowerTo });
      if (!recipient) {
        await session.abortTransaction();
        return res.status(404).json({
          success: false,
          message: 'Recipient @qumail.com address not found'
        });
      }
      
      let encryptedBody = body;
      let encryptionType = 'NONE';
      let aesKey = null;
      let aesIV = null;
      
      // Handle encryption
      if (encryptionLevel !== 'none') {
        try {
          if (encryptionLevel === 'otp') {
            // OTP encryption
            encryptionType = 'OTP';
            const textLength = Buffer.from(body, 'utf8').length;
            const otpKey = generateOTPKey(textLength);
            encryptedBody = otpEncrypt(body, otpKey);
            
            // Store OTP key in sender's encryption keys
            await User.findOneAndUpdate(
              { email: from },
              { $set: { "encryptionKeys.otp": otpKey } },
              { session }
            );
            
            console.log(`✅ OTP Encryption successful`);
            
          } else if (encryptionLevel === 'aes256') {
            // AES encryption
            encryptionType = 'AES';
            
            // Get sender's AES key or generate new one
            const sender = await User.findOne({ email: from });
            if (!sender.encryptionKeys?.aes256) {
              // Generate and save new AES key for sender
              aesKey = generateAESKey();
              await User.findOneAndUpdate(
                { email: from },
                { $set: { "encryptionKeys.aes256": aesKey } },
                { session }
              );
              console.log(`🔑 Generated new AES key for ${from}`);
            } else {
              aesKey = sender.encryptionKeys.aes256;
            }
            
            aesIV = generateAESIV();
            encryptedBody = encryptAES(body, aesKey, aesIV);
            
            console.log(`✅ AES Encryption successful`);
          }
        } catch (encryptionError) {
          await session.abortTransaction();
          console.error('Encryption failed:', encryptionError);
          return res.status(500).json({
            success: false,
            message: `Encryption failed: ${encryptionError.message}`
          });
        }
      }
      
      // Create mail objects with SAME mailId
      const mailId = uuidv4(); // ✅ ONE mailId for the entire email thread
      const timestamp = new Date();
      
      // Sent mail for sender
      await Mail.create([{
        mailId: mailId, // ✅ SAME ID
        from: from,
        to: lowerTo,
        subject: subject || '(No Subject)',
        body: body, // Original body for sender
        encryption: 'NONE', // Sender sees unencrypted
        aesKey: null,
        aesIV: null,
        folder: 'SENT',
        owner: from,
        read: true,
        createdAt: timestamp,
        updatedAt: timestamp
      }], { session });
      
      // Inbox mail for recipient (FIXED - SAME mailId)
      await Mail.create([{
        mailId: mailId, // ✅ SAME ID - CRITICAL FIX!
        from: from,
        to: lowerTo,
        subject: encryptionType !== 'NONE' ? `🔒 ${subject || 'Encrypted Message'}` : (subject || '(No Subject)'),
        body: encryptedBody,
        encryption: encryptionType,
        aesKey: aesKey,
        aesIV: aesIV,
        folder: 'INBOX',
        owner: lowerTo,
        read: false,
        createdAt: timestamp,
        updatedAt: timestamp
      }], { session });
      
      await session.commitTransaction();
      
      console.log(`✅ Email sent: ${mailId} from ${from} to ${to} (${encryptionLevel})`);
      console.log(`   ✅ SAME mailId for both copies: ${mailId}`);
      
      res.json({
        success: true,
        message: `Email sent successfully via QuMail (${encryptionLevel})`,
        messageId: mailId,
        sentAt: timestamp,
        encryption: {
          level: encryptionLevel,
          encrypted: encryptionLevel !== 'none',
          type: encryptionType
        }
      });
      
    } catch (error) {
      await session.abortTransaction();
      console.error('Send email error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to send email: ' + error.message
      });
    } finally {
      session.endSession();
    }
  }
);

// ------------------ GET INBOX EMAILS ------------------
app.post('/api/mail/inbox', verifyToken, async (req, res) => {
  try {
    const { limit = 50, page = 1 } = req.body;
    const email = req.user.email;
    const skip = (page - 1) * limit;
    
    console.log(`📥 Fetching inbox for: ${email}, page: ${page}, limit: ${limit}`);
    
    const [mails, total] = await Promise.all([
      Mail.find({
        owner: email,
        folder: 'INBOX',
        trash: false
      })
      .select('-aesKey -aesIV')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
      
      Mail.countDocuments({ 
        owner: email, 
        folder: 'INBOX', 
        trash: false 
      })
    ]);
    
    // Format emails for frontend
    const formattedEmails = mails.map(mail => ({
      id: mail.mailId,
      uid: mail.mailId,
      from: mail.from,
      to: mail.to,
      subject: mail.subject,
      body: mail.body,
      preview: mail.subject || 'No subject',
      date: mail.createdAt,
      originalDate: mail.createdAt,
      read: mail.read,
      starred: mail.starred,
      important: mail.important,
      draft: false,
      sent: false,
      trash: mail.trash,
      spam: false,
      archived: mail.folder === 'ARCHIVE',
      folder: mail.folder.toLowerCase(),
      encrypted: mail.encryption !== 'NONE',
      encryptionLevel: mail.encryption === 'AES' ? 'aes256' : 
                     mail.encryption === 'OTP' ? 'otp' : 'none',
      requiresDecryption: mail.encryption !== 'NONE',
      attachments: [],
      size: mail.body ? mail.body.length : 0
    }));
    
    res.json({
      success: true,
      emails: formattedEmails,
      count: formattedEmails.length,
      total: total,
      page: page,
      totalPages: Math.ceil(total / limit),
      folder: 'inbox'
    });
    
  } catch (error) {
    console.error('Fetch inbox error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch inbox',
      error: error.message
    });
  }
});

// ------------------ GET SENT EMAILS ------------------
app.post('/api/mail/sent', verifyToken, async (req, res) => {
  try {
    const { limit = 50, page = 1 } = req.body;
    const email = req.user.email;
    const skip = (page - 1) * limit;
    
    console.log(`📤 Fetching sent for: ${email}, page: ${page}, limit: ${limit}`);
    
    const [mails, total] = await Promise.all([
      Mail.find({
        owner: email,
        folder: 'SENT',
        trash: false
      })
      .select('-aesKey -aesIV')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
      
      Mail.countDocuments({ 
        owner: email, 
        folder: 'SENT', 
        trash: false 
      })
    ]);
    
    // Format emails for frontend
    const formattedEmails = mails.map(mail => ({
      id: mail.mailId,
      uid: mail.mailId,
      from: mail.from,
      to: mail.to,
      subject: mail.subject,
      body: mail.body,
      preview: mail.subject || 'No subject',
      date: mail.createdAt,
      originalDate: mail.createdAt,
      read: true,
      starred: mail.starred,
      important: mail.important,
      draft: false,
      sent: true,
      trash: mail.trash,
      spam: false,
      archived: mail.folder === 'ARCHIVE',
      folder: 'sent',
      encrypted: false,
      encryptionLevel: 'none',
      requiresDecryption: false,
      attachments: [],
      size: mail.body ? mail.body.length : 0
    }));
    
    res.json({
      success: true,
      emails: formattedEmails,
      count: formattedEmails.length,
      total: total,
      page: page,
      totalPages: Math.ceil(total / limit),
      folder: 'sent'
    });
    
  } catch (error) {
    console.error('Fetch sent error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch sent emails',
      error: error.message
    });
  }
});

// ------------------ GET ARCHIVE EMAILS ------------------
app.post('/api/mail/archive', verifyToken, async (req, res) => {
  try {
    const { limit = 50, page = 1 } = req.body;
    const email = req.user.email;
    const skip = (page - 1) * limit;
    
    console.log(`📁 Fetching archive for: ${email}, page: ${page}, limit: ${limit}`);
    
    const [mails, total] = await Promise.all([
      Mail.find({
        owner: email,
        folder: 'ARCHIVE',
        trash: false
      })
      .select('-aesKey -aesIV')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
      
      Mail.countDocuments({ 
        owner: email, 
        folder: 'ARCHIVE', 
        trash: false 
      })
    ]);
    
    // Format emails for frontend
    const formattedEmails = mails.map(mail => ({
      id: mail.mailId,
      uid: mail.mailId,
      from: mail.from,
      to: mail.to,
      subject: mail.subject,
      body: mail.body,
      preview: mail.subject || 'No subject',
      date: mail.createdAt,
      originalDate: mail.createdAt,
      read: mail.read,
      starred: mail.starred,
      important: mail.important,
      draft: false,
      sent: mail.folder === 'SENT',
      trash: mail.trash,
      spam: false,
      archived: true,
      folder: 'archive',
      encrypted: mail.encryption !== 'NONE',
      encryptionLevel: mail.encryption === 'AES' ? 'aes256' : 
                     mail.encryption === 'OTP' ? 'otp' : 'none',
      requiresDecryption: mail.encryption !== 'NONE',
      attachments: [],
      size: mail.body ? mail.body.length : 0
    }));
    
    res.json({
      success: true,
      emails: formattedEmails,
      count: formattedEmails.length,
      total: total,
      page: page,
      totalPages: Math.ceil(total / limit),
      folder: 'archive'
    });
    
  } catch (error) {
    console.error('Fetch archive error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch archive emails',
      error: error.message
    });
  }
});

// ------------------ GET TRASH EMAILS ------------------
app.post('/api/mail/trash', verifyToken, async (req, res) => {
  try {
    const { limit = 50, page = 1 } = req.body;
    const email = req.user.email;
    const skip = (page - 1) * limit;
    
    console.log(`🗑️ Fetching trash for: ${email}, page: ${page}, limit: ${limit}`);
    
    const [mails, total] = await Promise.all([
      Mail.find({
        owner: email,
        trash: true
      })
      .select('-aesKey -aesIV')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
      
      Mail.countDocuments({ 
        owner: email, 
        trash: true 
      })
    ]);
    
    // Format emails for frontend
    const formattedEmails = mails.map(mail => ({
      id: mail.mailId,
      uid: mail.mailId,
      from: mail.from,
      to: mail.to,
      subject: mail.subject,
      body: mail.body,
      preview: mail.subject || 'No subject',
      date: mail.createdAt,
      originalDate: mail.createdAt,
      read: mail.read,
      starred: mail.starred,
      important: mail.important,
      draft: false,
      sent: mail.folder === 'SENT',
      trash: true,
      spam: false,
      archived: false,
      folder: 'trash',
      encrypted: mail.encryption !== 'NONE',
      encryptionLevel: mail.encryption === 'AES' ? 'aes256' : 
                     mail.encryption === 'OTP' ? 'otp' : 'none',
      requiresDecryption: mail.encryption !== 'NONE',
      attachments: [],
      size: mail.body ? mail.body.length : 0
    }));
    
    res.json({
      success: true,
      emails: formattedEmails,
      count: formattedEmails.length,
      total: total,
      page: page,
      totalPages: Math.ceil(total / limit),
      folder: 'trash'
    });
    
  } catch (error) {
    console.error('Fetch trash error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch trash emails',
      error: error.message
    });
  }
});

// ------------------ GET STARRED EMAILS ------------------
app.post('/api/mail/starred', verifyToken, async (req, res) => {
  try {
    const { limit = 50, page = 1 } = req.body;
    const email = req.user.email;
    const skip = (page - 1) * limit;
    
    console.log(`⭐ Fetching starred for: ${email}, page: ${page}, limit: ${limit}`);
    
    const [mails, total] = await Promise.all([
      Mail.find({
        owner: email,
        starred: true,
        trash: false
      })
      .select('-aesKey -aesIV')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
      
      Mail.countDocuments({ 
        owner: email, 
        starred: true, 
        trash: false 
      })
    ]);
    
    // Format emails for frontend
    const formattedEmails = mails.map(mail => ({
      id: mail.mailId,
      uid: mail.mailId,
      from: mail.from,
      to: mail.to,
      subject: mail.subject,
      body: mail.body,
      preview: mail.subject || 'No subject',
      date: mail.createdAt,
      originalDate: mail.createdAt,
      read: mail.read,
      starred: true,
      important: mail.important,
      draft: false,
      sent: mail.folder === 'SENT',
      trash: false,
      spam: false,
      archived: mail.folder === 'ARCHIVE',
      folder: mail.folder.toLowerCase(),
      encrypted: mail.encryption !== 'NONE',
      encryptionLevel: mail.encryption === 'AES' ? 'aes256' : 
                     mail.encryption === 'OTP' ? 'otp' : 'none',
      requiresDecryption: mail.encryption !== 'NONE',
      attachments: [],
      size: mail.body ? mail.body.length : 0
    }));
    
    res.json({
      success: true,
      emails: formattedEmails,
      count: formattedEmails.length,
      total: total,
      page: page,
      totalPages: Math.ceil(total / limit),
      folder: 'starred'
    });
    
  } catch (error) {
    console.error('Fetch starred error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch starred emails',
      error: error.message
    });
  }
});

// ------------------ GET IMPORTANT EMAILS ------------------
app.post('/api/mail/important', verifyToken, async (req, res) => {
  try {
    const { limit = 50, page = 1 } = req.body;
    const email = req.user.email;
    const skip = (page - 1) * limit;
    
    console.log(`🔴 Fetching important for: ${email}, page: ${page}, limit: ${limit}`);
    
    const [mails, total] = await Promise.all([
      Mail.find({
        owner: email,
        important: true,
        trash: false
      })
      .select('-aesKey -aesIV')
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit),
      
      Mail.countDocuments({ 
        owner: email, 
        important: true, 
        trash: false 
      })
    ]);
    
    // Format emails for frontend
    const formattedEmails = mails.map(mail => ({
      id: mail.mailId,
      uid: mail.mailId,
      from: mail.from,
      to: mail.to,
      subject: mail.subject,
      body: mail.body,
      preview: mail.subject || 'No subject',
      date: mail.createdAt,
      originalDate: mail.createdAt,
      read: mail.read,
      starred: mail.starred,
      important: true,
      draft: false,
      sent: mail.folder === 'SENT',
      trash: false,
      spam: false,
      archived: mail.folder === 'ARCHIVE',
      folder: mail.folder.toLowerCase(),
      encrypted: mail.encryption !== 'NONE',
      encryptionLevel: mail.encryption === 'AES' ? 'aes256' : 
                     mail.encryption === 'OTP' ? 'otp' : 'none',
      requiresDecryption: mail.encryption !== 'NONE',
      attachments: [],
      size: mail.body ? mail.body.length : 0
    }));
    
    res.json({
      success: true,
      emails: formattedEmails,
      count: formattedEmails.length,
      total: total,
      page: page,
      totalPages: Math.ceil(total / limit),
      folder: 'important'
    });
    
  } catch (error) {
    console.error('Fetch important error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fetch important emails',
      error: error.message
    });
  }
});

// ------------------ GET SINGLE EMAIL (ENHANCED) ------------------
app.get('/api/mail/:mailId', verifyToken, async (req, res) => {
  try {
    const mailId = req.params.mailId;
    const userEmail = req.user.email;
    
    console.log(`📄 Fetching email: ${mailId} for ${userEmail}`);
    
    // Find the email
    const mail = await Mail.findOne({
      mailId: mailId,
      owner: userEmail
    });
    
    if (!mail) {
      return res.status(404).json({
        success: false,
        message: 'Email not found'
      });
    }
    
    // Mark as read when opened (if in inbox)
    if (mail.folder === 'INBOX' && !mail.read) {
      mail.read = true;
      await mail.save();
    }
    
    // Prepare response
    const response = {
      id: mail.mailId,
      uid: mail.mailId,
      from: mail.from,
      to: mail.to,
      subject: mail.subject,
      body: mail.body,
      date: mail.createdAt,
      originalDate: mail.createdAt,
      read: mail.read,
      starred: mail.starred,
      important: mail.important,
      draft: false,
      sent: mail.folder === 'SENT',
      trash: mail.trash,
      spam: false,
      archived: mail.folder === 'ARCHIVE',
      folder: mail.folder.toLowerCase(),
      encrypted: mail.encryption !== 'NONE',
      encryptionLevel: mail.encryption === 'AES' ? 'aes256' : 
                     mail.encryption === 'OTP' ? 'otp' : 'none',
      requiresDecryption: mail.encryption !== 'NONE',
      aesKey: mail.aesKey,
      aesIV: mail.aesIV,
      snoozed: mail.snoozed,
      labels: mail.labels || []
    };
    
    // ✅ ENHANCED: Add security information
    response.security = {
      encryption: mail.encryption,
      algorithm:
        mail.encryption === 'AES' ? 'AES-256-GCM' :
        mail.encryption === 'OTP' ? 'One-Time Pad' :
        'None',
      description:
        mail.encryption === 'AES' ? 'End-to-end encrypted with AES-256' :
        mail.encryption === 'OTP' ? 'Quantum-secure one-time pad encryption' :
        'Standard email (no encryption)'
    };
    
    // If encrypted with AES and keys exist, decrypt it automatically
    if (mail.encryption === 'AES' && mail.aesKey && mail.aesIV) {
      try {
        const decryptedBody = decryptAES(mail.body, mail.aesKey, mail.aesIV);
        response.body = decryptedBody;
        response.decrypted = true;
        response.requiresDecryption = false;
        response.security.decrypted = true;
        response.security.decryptionMethod = 'automatic';
      } catch (decryptError) {
        console.error('AES decryption error:', decryptError);
        response.decryptionError = 'Failed to decrypt AES email';
        response.security.decryptionError = 'Automatic decryption failed';
      }
    } else if (mail.encryption === 'OTP') {
      response.security.decryptionMethod = 'manual';
      response.security.keyRequired = true;
    }
    
    res.json({
      success: true,
      email: response
    });
    
  } catch (error) {
    console.error('Get email error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get email',
      error: error.message
    });
  }
});

// ================== EMAIL STATUS MANAGEMENT ==================

// ------------------ UPDATE SINGLE EMAIL STATUS (FIXED & WORKING) ------------------
app.put('/api/mail/:mailId/status', 
  [
    verifyToken,
    body('action').isIn(['star', 'unstar', 'important', 'unimportant', 'archive', 'unarchive', 'trash', 'delete', 'restore', 'read', 'unread', 'snooze', 'unsnooze', 'move']).withMessage('Invalid action'),
  ],
  async (req, res) => {
    try {
      const { mailId } = req.params;
      const { action, folder, snoozeDate } = req.body;
      const userEmail = req.user.email;
      
      console.log(`⚡ Updating status for email: ${mailId}, action: ${action} by user: ${userEmail}`);
      console.log(`   Request body:`, { action, folder, snoozeDate });
      
      // First, find the email to verify it exists
      const mail = await Mail.findOne({
        mailId: mailId,
        owner: userEmail
      });
      
      if (!mail) {
        console.log(`❌ Email not found: ${mailId} for user ${userEmail}`);
        return res.status(404).json({
          success: false,
          message: 'Email not found'
        });
      }
      
      console.log(`✅ Found email: ${mail.mailId}, subject: "${mail.subject}"`);
      
      let updateData = {};
      let message = '';
      let responseData = {};
      
      // Set update data based on action
      switch (action) {
        case 'star':
          updateData.starred = true;
          message = 'Email starred successfully';
          responseData = { 
            starred: true,
            id: mail.mailId
          };
          break;
          
        case 'unstar':
          updateData.starred = false;
          message = 'Email unstarred successfully';
          responseData = { 
            starred: false,
            id: mail.mailId
          };
          break;
          
        case 'important':
          updateData.important = true;
          message = 'Email marked as important';
          responseData = { 
            important: true,
            id: mail.mailId
          };
          break;
          
        case 'unimportant':
          updateData.important = false;
          message = 'Email removed from important';
          responseData = { 
            important: false,
            id: mail.mailId
          };
          break;
          
        case 'read':
          updateData.read = true;
          message = 'Email marked as read';
          responseData = { 
            read: true,
            id: mail.mailId
          };
          break;
          
        case 'unread':
          updateData.read = false;
          message = 'Email marked as unread';
          responseData = { 
            read: false,
            id: mail.mailId
          };
          break;
          
        case 'archive':
          updateData.folder = 'ARCHIVE';
          updateData.trash = false;
          message = 'Email archived successfully';
          responseData = { 
            folder: 'archive',
            archived: true,
            trash: false,
            id: mail.mailId
          };
          break;
          
        case 'unarchive':
          const originalFolder = mail.to === userEmail ? 'INBOX' : 'SENT';
          updateData.folder = originalFolder;
          updateData.trash = false;
          message = 'Email moved to ' + (originalFolder === 'INBOX' ? 'inbox' : 'sent');
          responseData = { 
            folder: originalFolder.toLowerCase(),
            archived: false,
            trash: false,
            id: mail.mailId
          };
          break;
          
        case 'trash':
          updateData.trash = true;
          message = 'Email moved to trash';
          responseData = { 
            trash: true,
            folder: mail.folder.toLowerCase(),
            id: mail.mailId
          };
          break;
          
        case 'delete':
          // Permanent delete - use deleteOne instead of findOneAndDelete
          const deleteResult = await Mail.deleteOne({
            mailId: mailId,
            owner: userEmail
          });
          
          console.log(`🗑️ Permanent delete result:`, deleteResult);
          
          if (deleteResult.deletedCount === 0) {
            return res.status(404).json({
              success: false,
              message: 'Email not found for deletion'
            });
          }
          
          return res.json({
            success: true,
            message: 'Email permanently deleted',
            emailId: mailId,
            deleted: true
          });
          
        case 'restore':
          updateData.trash = false;
          message = 'Email restored from trash';
          responseData = { 
            trash: false,
            folder: mail.folder.toLowerCase(),
            id: mail.mailId
          };
          break;
          
        case 'snooze':
          if (!snoozeDate) {
            return res.status(400).json({
              success: false,
              message: 'snoozeDate is required for snooze action'
            });
          }
          updateData.snoozed = new Date(snoozeDate);
          message = `Email snoozed until ${snoozeDate}`;
          responseData = { 
            snoozed: snoozeDate,
            id: mail.mailId
          };
          break;
          
        case 'unsnooze':
          updateData.snoozed = null;
          message = 'Email unsnoozed';
          responseData = { 
            snoozed: null,
            id: mail.mailId
          };
          break;
          
        case 'move':
          if (!folder || !['inbox', 'sent', 'archive'].includes(folder.toLowerCase())) {
            return res.status(400).json({
              success: false,
              message: 'Valid folder is required for move action (inbox, sent, archive)'
            });
          }
          
          const targetFolder = folder.toUpperCase();
          updateData.folder = targetFolder;
          updateData.trash = false;
          
          message = `Email moved to ${folder}`;
          responseData = { 
            folder: folder.toLowerCase(),
            archived: targetFolder === 'ARCHIVE',
            trash: false,
            id: mail.mailId
          };
          break;
          
        default:
          return res.status(400).json({
            success: false,
            message: 'Invalid action'
          });
      }
      
      console.log(`📝 Update data to apply:`, updateData);
      
      // IMPORTANT FIX: Use updateOne instead of findOneAndUpdate
      const updateResult = await Mail.updateOne(
        {
          mailId: mailId,
          owner: userEmail
        },
        { $set: updateData }
      );
      
      console.log(`📊 Update result:`, updateResult);
      
      if (updateResult.modifiedCount === 0 && updateResult.matchedCount === 0) {
        console.log(`❌ No email found to update`);
        return res.status(404).json({
          success: false,
          message: 'Email not found or no changes needed'
        });
      }
      
      if (updateResult.modifiedCount === 0 && updateResult.matchedCount > 0) {
        console.log(`ℹ️ Email found but no changes needed (already in desired state)`);
      }
      
      // Get the updated email to return in response
      const updatedMail = await Mail.findOne({
        mailId: mailId,
        owner: userEmail
      });
      
      if (!updatedMail) {
        console.log(`⚠️ Could not fetch updated email, but update succeeded`);
        // Still return success since update worked
        return res.json({
          success: true,
          message: message,
          email: {
            id: mailId,
            ...responseData
          }
        });
      }
      
      console.log(`✅ Email updated successfully: ${updatedMail.mailId}`);
      console.log(`   New status:`, {
        starred: updatedMail.starred,
        important: updatedMail.important,
        read: updatedMail.read,
        trash: updatedMail.trash,
        folder: updatedMail.folder
      });
      
      res.json({
        success: true,
        message: message,
        email: {
          id: updatedMail.mailId,
          ...responseData,
          starred: updatedMail.starred,
          important: updatedMail.important,
          read: updatedMail.read,
          folder: updatedMail.folder.toLowerCase()
        }
      });
      
    } catch (error) {
      console.error('Update email status error:', error);
      res.status(500).json({
        success: false,
        message: `Failed to update email: ${error.message}`,
        details: error.message,
        stack: process.env.NODE_ENV === 'development' ? error.stack : undefined
      });
    }
  }
);

// ------------------ BATCH UPDATE EMAILS (CORRECTED) ------------------
app.post('/api/mail/batch-update', 
  [
    verifyToken,
    body('emailIds').isArray({ min: 1 }).withMessage('emailIds must be a non-empty array'),
    body('action').isIn(['star', 'unstar', 'important', 'unimportant', 'archive', 'unarchive', 'trash', 'delete', 'restore', 'read', 'unread', 'move']).withMessage('Invalid action'),
  ],
  async (req, res) => {
    try {
      const { emailIds, action, folder } = req.body;
      const userEmail = req.user.email;
      
      console.log(`⚡ Batch updating ${emailIds.length} emails, action: ${action} by user: ${userEmail}`);
      
      // Validate emailIds
      if (!Array.isArray(emailIds) || emailIds.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Please provide email IDs to update'
        });
      }
      
      // Build update query based on action
      let updateQuery = {};
      let message = '';
      
      switch (action) {
        case 'star':
          updateQuery = { $set: { starred: true } };
          message = 'emails starred successfully';
          break;
          
        case 'unstar':
          updateQuery = { $set: { starred: false } };
          message = 'emails unstarred successfully';
          break;
          
        case 'important':
          updateQuery = { $set: { important: true } };
          message = 'emails marked as important';
          break;
          
        case 'unimportant':
          updateQuery = { $set: { important: false } };
          message = 'emails removed from important';
          break;
          
        case 'read':
          updateQuery = { $set: { read: true } };
          message = 'emails marked as read';
          break;
          
        case 'unread':
          updateQuery = { $set: { read: false } };
          message = 'emails marked as unread';
          break;
          
        case 'archive':
          updateQuery = { 
            $set: { 
              folder: 'ARCHIVE',
              trash: false 
            } 
          };
          message = 'emails archived successfully';
          break;
          
        case 'unarchive':
          // Find emails to unarchive
          const emailsToUnarchive = await Mail.find({ 
            mailId: { $in: emailIds }, 
            owner: userEmail 
          });
          
          const bulkOps = emailsToUnarchive.map(mail => {
            const originalFolder = mail.to === userEmail ? 'INBOX' : 'SENT';
            return {
              updateOne: {
                filter: { mailId: mail.mailId, owner: userEmail },
                update: { 
                  $set: { 
                    folder: originalFolder,
                    trash: false 
                  } 
                }
              }
            };
          });
          
          if (bulkOps.length > 0) {
            await Mail.bulkWrite(bulkOps);
          }
          
          return res.json({
            success: true,
            message: `Emails unarchived successfully`,
            count: bulkOps.length
          });
          
        case 'trash':
          updateQuery = { $set: { trash: true } };
          message = 'emails moved to trash';
          break;
          
        case 'delete':
          // Permanent delete
          const deleteResult = await Mail.deleteMany({ 
            mailId: { $in: emailIds }, 
            owner: userEmail 
          });
          
          console.log(`🗑️ Batch delete result: ${deleteResult.deletedCount} emails deleted`);
          
          return res.json({
            success: true,
            message: `${deleteResult.deletedCount} emails permanently deleted`,
            count: deleteResult.deletedCount
          });
          
        case 'restore':
          updateQuery = { $set: { trash: false } };
          message = 'emails restored from trash';
          break;
          
        case 'move':
          if (!folder || !['inbox', 'sent', 'archive'].includes(folder.toLowerCase())) {
            return res.status(400).json({
              success: false,
              message: 'Valid folder is required for move action (inbox, sent, archive)'
            });
          }
          
          const targetFolder = folder.toUpperCase();
          updateQuery = { 
            $set: { 
              folder: targetFolder,
              trash: false 
            } 
          };
          message = `emails moved to ${folder}`;
          break;
          
        default:
          return res.status(400).json({
            success: false,
            message: 'Invalid action'
          });
      }
      
      // Execute batch update
      let updateResult;
      if (action !== 'unarchive' && action !== 'delete') {
        updateResult = await Mail.updateMany(
          { 
            mailId: { $in: emailIds }, 
            owner: userEmail 
          },
          updateQuery
        );
        
        console.log(`✅ Batch update result: ${updateResult.modifiedCount} emails updated`);
      }
      
      res.json({
        success: true,
        message: `${message}`,
        count: updateResult?.modifiedCount || emailsToUnarchive?.length || 0,
        action: action,
        folder: folder || null
      });
      
    } catch (error) {
      console.error('Batch update error:', error);
      res.status(500).json({
        success: false,
        message: `Failed to batch update emails: ${error.message}`
      });
    }
  }
);

// ------------------ MOVE EMAILS TO FOLDER ------------------
app.post('/api/mail/move-to-folder', 
  [
    verifyToken,
    body('emailIds').isArray({ min: 1 }).withMessage('emailIds must be a non-empty array'),
    body('targetFolder').isIn(['inbox', 'sent', 'archive', 'trash']).withMessage('Valid targetFolder is required (inbox, sent, archive, trash)'),
  ],
  async (req, res) => {
    try {
      const { emailIds, targetFolder } = req.body;
      const userEmail = req.user.email;
      
      console.log(`📂 Moving ${emailIds.length} emails to ${targetFolder} for user: ${userEmail}`);
      
      if (!Array.isArray(emailIds) || emailIds.length === 0) {
        return res.status(400).json({
          success: false,
          message: 'Please provide email IDs to move'
        });
      }
      
      let updateQuery = {};
      let message = '';
      
      if (targetFolder === 'trash') {
        updateQuery = { $set: { trash: true } };
        message = 'emails moved to trash';
      } else {
        const folderUpper = targetFolder.toUpperCase();
        updateQuery = { 
          $set: { 
            folder: folderUpper,
            trash: false
          } 
        };
        message = `emails moved to ${targetFolder}`;
      }
      
      // Execute the move
      const updateResult = await Mail.updateMany(
        { 
          mailId: { $in: emailIds }, 
          owner: userEmail 
        },
        updateQuery
      );
      
      console.log(`✅ Move result: ${updateResult.modifiedCount} emails moved to ${targetFolder}`);
      
      res.json({
        success: true,
        message: `${updateResult.modifiedCount} ${message}`,
        count: updateResult.modifiedCount,
        targetFolder: targetFolder
      });
      
    } catch (error) {
      console.error('Move emails error:', error);
      res.status(500).json({
        success: false,
        message: `Failed to move emails: ${error.message}`
      });
    }
  }
);

// ------------------ BULK EMAIL ACTIONS ------------------
app.post('/api/mail/bulk-actions', 
  [
    verifyToken,
    body('action').isIn(['star', 'unstar', 'important', 'unimportant', 'read', 'unread']).withMessage('Invalid action'),
    body('folder').optional().isIn(['inbox', 'sent', 'archive', 'trash', 'starred', 'important']).withMessage('Invalid folder'),
  ],
  async (req, res) => {
    try {
      const { action, folder } = req.body;
      const userEmail = req.user.email;
      
      console.log(`⚡ Bulk action: ${action} on folder: ${folder || 'all'} for user: ${userEmail}`);
      
      // Build filter query based on folder
      let filterQuery = { owner: userEmail, trash: false };
      
      if (folder) {
        switch (folder) {
          case 'inbox':
            filterQuery.folder = 'INBOX';
            break;
          case 'sent':
            filterQuery.folder = 'SENT';
            break;
          case 'archive':
            filterQuery.folder = 'ARCHIVE';
            break;
          case 'trash':
            filterQuery.trash = true;
            break;
          case 'starred':
            filterQuery.starred = true;
            break;
          case 'important':
            filterQuery.important = true;
            break;
        }
      }
      
      // Build update query based on action
      let updateQuery = {};
      let message = '';
      
      switch (action) {
        case 'star':
          updateQuery = { $set: { starred: true } };
          message = 'All emails starred';
          break;
        case 'unstar':
          updateQuery = { $set: { starred: false } };
          message = 'All emails unstarred';
          break;
        case 'important':
          updateQuery = { $set: { important: true } };
          message = 'All emails marked as important';
          break;
        case 'unimportant':
          updateQuery = { $set: { important: false } };
          message = 'All emails removed from important';
          break;
        case 'read':
          updateQuery = { $set: { read: true } };
          message = 'All emails marked as read';
          break;
        case 'unread':
          updateQuery = { $set: { read: false } };
          message = 'All emails marked as unread';
          break;
      }
      
      // Execute bulk update
      const updateResult = await Mail.updateMany(filterQuery, updateQuery);
      
      res.json({
        success: true,
        message: `${message} (${updateResult.modifiedCount} emails updated)`,
        count: updateResult.modifiedCount,
        action: action,
        folder: folder || 'all'
      });
      
    } catch (error) {
      console.error('Bulk action error:', error);
      res.status(500).json({
        success: false,
        message: `Failed to perform bulk action: ${error.message}`
      });
    }
  }
);

// ------------------ GET EMAILS BY FOLDER ------------------
app.post('/api/mail/folder/:folderName', verifyToken, async (req, res) => {
  try {
    const { folderName } = req.params;
    const { limit = 50, page = 1, filter } = req.body;
    const userEmail = req.user.email;
    
    const skip = (page - 1) * limit;
    
    console.log(`📁 Fetching ${folderName} folder emails for: ${userEmail}, page: ${page}`);
    
    // Build base query
    let query = { owner: userEmail };
    
    // Apply folder-specific filters
    switch (folderName.toLowerCase()) {
      case 'inbox':
        query.folder = 'INBOX';
        query.trash = false;
        break;
      case 'sent':
        query.folder = 'SENT';
        query.trash = false;
        break;
      case 'archive':
        query.folder = 'ARCHIVE';
        query.trash = false;
        break;
      case 'trash':
        query.trash = true;
        break;
      case 'starred':
        query.starred = true;
        query.trash = false;
        break;
      case 'important':
        query.important = true;
        query.trash = false;
        break;
      case 'unread':
        query.read = false;
        query.folder = 'INBOX';
        query.trash = false;
        break;
      default:
        return res.status(400).json({
          success: false,
          message: 'Invalid folder name'
        });
    }
    
    // Apply additional filters if provided
    if (filter) {
      if (filter === 'unread') {
        query.read = false;
      } else if (filter === 'starred') {
        query.starred = true;
      } else if (filter === 'important') {
        query.important = true;
      }
    }
    
    // Get emails with pagination
    const [mails, total] = await Promise.all([
      Mail.find(query)
        .select('-aesKey -aesIV')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Mail.countDocuments(query)
    ]);
    
    // Format emails
    const formattedEmails = mails.map(mail => ({
      id: mail.mailId,
      uid: mail.mailId,
      from: mail.from,
      to: mail.to,
      subject: mail.subject,
      body: mail.body,
      preview: mail.subject || 'No subject',
      date: mail.createdAt,
      originalDate: mail.createdAt,
      read: mail.read,
      starred: mail.starred,
      important: mail.important,
      draft: false,
      sent: mail.folder === 'SENT',
      trash: mail.trash,
      spam: false,
      archived: mail.folder === 'ARCHIVE',
      folder: mail.folder.toLowerCase(),
      encrypted: mail.encryption !== 'NONE',
      encryptionLevel: mail.encryption === 'AES' ? 'aes256' : 
                     mail.encryption === 'OTP' ? 'otp' : 'none',
      requiresDecryption: mail.encryption !== 'NONE',
      attachments: [],
      size: mail.body ? mail.body.length : 0
    }));
    
    res.json({
      success: true,
      emails: formattedEmails,
      count: formattedEmails.length,
      total: total,
      page: page,
      totalPages: Math.ceil(total / limit),
      folder: folderName.toLowerCase()
    });
    
  } catch (error) {
    console.error(`Fetch ${folderName} folder error:`, error);
    res.status(500).json({
      success: false,
      message: `Failed to fetch ${folderName} emails`,
      error: error.message
    });
  }
});

// ------------------ EMPTY TRASH ------------------
app.post('/api/mail/empty-trash', verifyToken, async (req, res) => {
  try {
    const userEmail = req.user.email;
    
    console.log(`🗑️ Emptying trash for user: ${userEmail}`);
    
    const deleteResult = await Mail.deleteMany({ 
      owner: userEmail, 
      trash: true 
    });
    
    res.json({
      success: true,
      message: `Trash emptied successfully (${deleteResult.deletedCount} emails deleted)`,
      count: deleteResult.deletedCount
    });
    
  } catch (error) {
    console.error('Empty trash error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to empty trash',
      error: error.message
    });
  }
});

// ------------------ DECRYPT EMAIL ------------------
app.post('/api/decrypt', 
  [
    verifyToken,
    body('emailId').notEmpty().withMessage('Email ID is required')
  ],
  async (req, res) => {
    try {
      const { emailId, encryptionKey } = req.body;
      const userEmail = req.user.email;
      
      console.log(`🔓 Decrypt request for email: ${emailId} by user: ${userEmail}`);
      
      // Find the email
      const mail = await Mail.findOne({
        mailId: emailId,
        owner: userEmail
      });
      
      if (!mail) {
        return res.status(404).json({
          success: false,
          message: 'Email not found'
        });
      }
      
      // Check if email is encrypted
      if (mail.encryption === 'NONE') {
        return res.json({
          success: true,
          decrypted: mail.body,
          encryptionLevel: 'none',
          alreadyDecrypted: true
        });
      }
      
      let decryptedBody;
      
      // Handle decryption based on encryption type
      if (mail.encryption === 'AES') {
        if (!mail.aesKey || !mail.aesIV) {
          return res.status(400).json({
            success: false,
            message: 'AES key or IV missing from email record'
          });
        }
        
        try {
          // Decrypt AES
          decryptedBody = decryptAES(mail.body, mail.aesKey, mail.aesIV);
          console.log(`✅ AES decryption successful for email: ${emailId}`);
        } catch (decryptError) {
          console.error('AES decryption error:', decryptError);
          return res.status(500).json({
            success: false,
            message: 'AES decryption failed. The email may be corrupted.'
          });
        }
      } 
      else if (mail.encryption === 'OTP') {
        // For OTP, require encryption key
        if (!encryptionKey) {
          return res.status(400).json({
            success: false,
            message: 'OTP key is required for decryption'
          });
        }
        
        try {
          // Validate OTP key format
          if (!isValidHexKey(encryptionKey)) {
            return res.status(400).json({
              success: false,
              message: 'Invalid OTP key format. Must be hexadecimal.'
            });
          }
          
          // Decrypt OTP
          decryptedBody = otpDecrypt(mail.body, encryptionKey);
          console.log(`✅ OTP decryption successful for email: ${emailId}`);
        } catch (decryptError) {
          console.error('OTP decryption error:', decryptError);
          return res.status(400).json({
            success: false,
            message: 'OTP decryption failed. Make sure the key is correct.'
          });
        }
      } else {
        return res.status(400).json({
          success: false,
          message: 'Unsupported encryption type'
        });
      }
      
      // Update mail to mark as read
      if (!mail.read) {
        mail.read = true;
        await mail.save();
      }
      
      res.json({
        success: true,
        decrypted: decryptedBody,
        encryptionLevel: mail.encryption === 'AES' ? 'aes256' : 'otp',
        decryptedAt: new Date().toISOString(),
        emailId: mail.mailId
      });
      
    } catch (error) {
      console.error('Decrypt email error:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to decrypt email: ' + error.message
      });
    }
  }
);

// ------------------ SEARCH EMAILS ------------------
app.post('/api/mail/search', verifyToken, async (req, res) => {
  try {
    const { query, folder, limit = 50 } = req.body;
    const userEmail = req.user.email;
    
    console.log(`🔍 Searching emails for: ${userEmail}, query: ${query}, folder: ${folder}`);
    
    if (!query || query.trim().length === 0) {
      return res.status(400).json({
        success: false,
        message: 'Search query is required'
      });
    }
    
    // Build search query
    const searchQuery = {
      owner: userEmail,
      trash: false,
      $or: [
        { subject: { $regex: query, $options: 'i' } },
        { body: { $regex: query, $options: 'i' } },
        { from: { $regex: query, $options: 'i' } },
        { to: { $regex: query, $options: 'i' } }
      ]
    };
    
    // Add folder filter if specified
    if (folder && folder !== 'all') {
      if (folder === 'trash') {
        searchQuery.trash = true;
      } else if (folder === 'starred') {
        searchQuery.starred = true;
      } else if (folder === 'important') {
        searchQuery.important = true;
      } else if (folder === 'archive') {
        searchQuery.folder = 'ARCHIVE';
      } else if (folder === 'sent') {
        searchQuery.folder = 'SENT';
      } else {
        searchQuery.folder = 'INBOX';
      }
    }
    
    const mails = await Mail.find(searchQuery)
      .select('-aesKey -aesIV')
      .sort({ createdAt: -1 })
      .limit(limit);
    
    // Format emails for frontend
    const formattedEmails = mails.map(mail => ({
      id: mail.mailId,
      uid: mail.mailId,
      from: mail.from,
      to: mail.to,
      subject: mail.subject,
      body: mail.body,
      preview: mail.subject || 'No subject',
      date: mail.createdAt,
      originalDate: mail.createdAt,
      read: mail.read,
      starred: mail.starred,
      important: mail.important,
      draft: false,
      sent: mail.folder === 'SENT',
      trash: mail.trash,
      spam: false,
      archived: mail.folder === 'ARCHIVE',
      folder: mail.folder.toLowerCase(),
      encrypted: mail.encryption !== 'NONE',
      encryptionLevel: mail.encryption === 'AES' ? 'aes256' : 
                     mail.encryption === 'OTP' ? 'otp' : 'none',
      requiresDecryption: mail.encryption !== 'NONE',
      attachments: [],
      size: mail.body ? mail.body.length : 0
    }));
    
    res.json({
      success: true,
      emails: formattedEmails,
      count: formattedEmails.length,
      total: await Mail.countDocuments(searchQuery),
      folder: folder || 'all',
      query: query
    });
    
  } catch (error) {
    console.error('Search emails error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to search emails',
      error: error.message
    });
  }
});

// ------------------ GET FOLDER COUNTS ------------------
app.get('/api/mail/folder-counts', verifyToken, async (req, res) => {
  try {
    const userEmail = req.user.email;
    
    const [inbox, sent, archive, trash, starred, important] = await Promise.all([
      Mail.countDocuments({ owner: userEmail, folder: 'INBOX', trash: false }),
      Mail.countDocuments({ owner: userEmail, folder: 'SENT', trash: false }),
      Mail.countDocuments({ owner: userEmail, folder: 'ARCHIVE', trash: false }),
      Mail.countDocuments({ owner: userEmail, trash: true }),
      Mail.countDocuments({ owner: userEmail, starred: true, trash: false }),
      Mail.countDocuments({ owner: user.email, important: true, trash: false })
    ]);
    
    const unreadCount = await Mail.countDocuments({ 
      owner: userEmail, 
      folder: 'INBOX', 
      read: false, 
      trash: false 
    });
    
    res.json({
      success: true,
      counts: {
        inbox: inbox,
        sent: sent,
        archive: archive,
        trash: trash,
        starred: starred,
        important: important,
        unread: unreadCount
      }
    });
    
  } catch (error) {
    console.error('Get folder counts error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to get folder counts',
      error: error.message
    });
  }
});

// ------------------ LOGOUT ------------------
app.post('/api/logout', verifyToken, (req, res) => {
  try {
    console.log(`👋 User logged out: ${req.user.email}`);
    
    res.json({
      success: true,
      message: 'Logged out successfully from QuMail'
    });
    
  } catch (error) {
    console.error('Logout error:', error);
    res.status(500).json({
      success: false,
      message: 'Internal server error'
    });
  }
});

// ------------------ DEBUG: FIX DUPLICATE MAIL IDs ------------------
app.post('/api/debug/fix-mailids', verifyToken, async (req, res) => {
  try {
    const userEmail = req.user.email;
    console.log(`🔧 Fixing duplicate mailIds for user: ${userEmail}`);
    
    // Find sent emails
    const sentEmails = await Mail.find({ 
      owner: userEmail, 
      folder: 'SENT' 
    }).sort({ createdAt: -1 }).limit(100);
    
    let fixedCount = 0;
    
    for (const sentEmail of sentEmails) {
      // Find matching inbox email
      const inboxEmail = await Mail.findOne({
        from: sentEmail.from,
        to: sentEmail.to,
        createdAt: { 
          $gte: new Date(sentEmail.createdAt.getTime() - 1000),
          $lte: new Date(sentEmail.createdAt.getTime() + 1000)
        },
        folder: 'INBOX',
        owner: sentEmail.to
      });
      
      if (inboxEmail && sentEmail.mailId !== inboxEmail.mailId) {
        console.log(`🔄 Fixing: Sent=${sentEmail.mailId}, Inbox=${inboxEmail.mailId}`);
        
        // Update inbox to use sent email's mailId
        inboxEmail.mailId = sentEmail.mailId;
        await inboxEmail.save();
        fixedCount++;
      }
    }
    
    res.json({
      success: true,
      message: `Fixed ${fixedCount} email ID mismatches`,
      fixedCount: fixedCount
    });
    
  } catch (error) {
    console.error('Fix mailIds error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to fix mailIds'
    });
  }
});

// ------------------ SEED TEST DATA ------------------
app.post('/api/seed-test-data', async (req, res) => {
  try {
    const testUser = 'test@qumail.com';
    const testPassword = 'TestPassword123!';
    
    // Check if user already exists
    let user = await User.findOne({ email: testUser });
    
    if (!user) {
      // Create test user
      const salt = await bcrypt.genSalt(12);
      const hashedPassword = await bcrypt.hash(testPassword, salt);
      
      const otpKey = generateOTPKey(256);
      const aesKey = generateAESKey();
      
      user = await User.create({
        name: 'Test User',
        email: testUser,
        password: hashedPassword,
        settings: {
          emailNotifications: true,
          autoSaveDrafts: true,
          signature: 'Best regards,\nTest User',
          twoFactorEnabled: false,
          language: 'en',
          timezone: 'UTC'
        },
        encryptionKeys: {
          otp: otpKey,
          aes256: aesKey
        },
        storageUsed: 250 * 1024 * 1024, // 250MB
        storageLimit: 10 * 1024 * 1024 * 1024, // 10GB
        isVerified: true,
        role: 'user',
        lastLogin: new Date()
      });
      
      console.log(`✅ Test user created: ${testUser}`);
    }
    
    // Clear existing test emails
    await Mail.deleteMany({ owner: testUser });
    
    // Seed test emails
    const now = new Date();
    const testEmails = [];
    
    for (let i = 1; i <= 20; i++) {
      const fromEmail = `sender${i}@qumail.com`;
      const mailId = uuidv4(); // ✅ SAME mailId for both copies
      const body = `This is test email ${i} content. Welcome to QuMail!\n\nThis email contains test content to demonstrate the QuMail platform features. You can reply, forward, or delete this email.\n\nRegards,\nSender ${i}`;
      
      // Create sender account if not exists
      await User.findOneAndUpdate(
        { email: fromEmail },
        {
          name: `Sender ${i}`,
          password: await bcrypt.hash('TestPassword123!', 12),
          settings: {
            emailNotifications: true,
            autoSaveDrafts: true,
            signature: '',
            twoFactorEnabled: false,
            language: 'en',
            timezone: 'UTC'
          },
          encryptionKeys: {
            otp: generateOTPKey(256),
            aes256: generateAESKey()
          }
        },
        { upsert: true }
      );
      
      const isEncrypted = i % 3 === 0;
      const isAES = i % 2 === 0;
      let encryptedBody = body;
      let aesKey = null;
      let aesIV = null;
      let folder = 'INBOX';
      
      if (i % 5 === 0) folder = 'ARCHIVE';
      
      if (isEncrypted && isAES) {
        // Create AES encrypted email
        aesKey = generateAESKey();
        aesIV = generateAESIV();
        encryptedBody = encryptAES(body, aesKey, aesIV);
      } else if (isEncrypted) {
        // Create OTP encrypted email
        const otpKey = generateOTPKey(body.length);
        encryptedBody = otpEncrypt(body, otpKey);
      }
      
      // Add to test user's inbox (same mailId)
      testEmails.push({
        mailId: mailId, // ✅ SAME ID
        from: fromEmail,
        to: testUser,
        subject: isEncrypted ? `🔒 Encrypted Test Email ${i}` : `Test Email ${i}`,
        body: encryptedBody,
        encryption: isEncrypted ? (isAES ? 'AES' : 'OTP') : 'NONE',
        aesKey: aesKey,
        aesIV: aesIV,
        folder: folder,
        owner: testUser,
        read: i % 2 === 0,
        starred: i % 4 === 0,
        important: i % 5 === 0,
        createdAt: new Date(now.getTime() - (i * 3600000))
      });
      
      // Add to sender's sent folder (same mailId)
      testEmails.push({
        mailId: mailId, // ✅ SAME ID
        from: fromEmail,
        to: testUser,
        subject: `Test Email ${i}`,
        body: body,
        encryption: 'NONE',
        aesKey: null,
        aesIV: null,
        folder: 'SENT',
        owner: fromEmail,
        read: true,
        starred: false,
        important: false,
        createdAt: new Date(now.getTime() - (i * 3600000))
      });
    }
    
    await Mail.insertMany(testEmails);
    
    res.json({
      success: true,
      message: 'Test data seeded successfully',
      user: {
        email: testUser,
        password: testPassword
      },
      counts: {
        inbox: testEmails.filter(e => e.folder === 'INBOX' && e.owner === testUser).length,
        sent: testEmails.filter(e => e.folder === 'SENT' && e.owner === testUser).length,
        archive: testEmails.filter(e => e.folder === 'ARCHIVE' && e.owner === testUser).length
      }
    });
    
  } catch (error) {
    console.error('Seed data error:', error);
    res.status(500).json({
      success: false,
      message: 'Failed to seed test data'
    });
  }
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(500).json({
    success: false,
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? err.message : undefined
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Endpoint ${req.method} ${req.path} not found`
  });
});

// ------------------ START SERVER ------------------
const server = app.listen(PORT, () => {
  const dbStatus = isMongoConnected() ? '✓ Connected' : '✗ Not connected';
  
  console.log(`\n🚀 QuMail Quantum Platform Server`);
  console.log(`========================================`);
  console.log(`🔗 Base URL: http://localhost:${PORT}`);
  console.log(`📧 Platform: Independent @qumail.com Network`);
  console.log(`🔐 Security: End-to-End Quantum-Resistant Encryption`);
  console.log(`⚙️  Environment: ${process.env.NODE_ENV || 'development'}`);
  console.log(`🗄️  Database: ${dbStatus}`);
  console.log(`📁 Upload Directory: ${path.join(__dirname, 'uploads')}`);
  console.log(`\n📋 Available Endpoints:`);
  console.log(`   POST /api/register              - Register new user`);
  console.log(`   POST /api/login                 - Login`);
  console.log(`   GET  /api/profile              - Get user profile`);
  console.log(`   PUT  /api/profile              - Update user profile`);
  console.log(`   POST /api/change-password      - Change password`);
  console.log(`   POST /api/upload-avatar        - Upload avatar (Base64)`);
  console.log(`   DELETE /api/avatar             - Delete avatar`);
  console.log(`   POST /api/send                 - Send email (supports OTP/AES/none)`);
  console.log(`   POST /api/mail/inbox           - Get inbox emails`);
  console.log(`   POST /api/mail/sent            - Get sent emails`);
  console.log(`   POST /api/mail/archive         - Get archive emails`);
  console.log(`   POST /api/mail/trash           - Get trash emails`);
  console.log(`   POST /api/mail/starred         - Get starred emails`);
  console.log(`   POST /api/mail/important       - Get important emails`);
  console.log(`   GET  /api/mail/:mailId         - Get single email`);
  console.log(`   PUT  /api/mail/:mailId/status  - Update email status`);
  console.log(`   POST /api/mail/batch-update    - Batch update emails`);
  console.log(`   POST /api/mail/move-to-folder  - Move emails to folder`);
  console.log(`   POST /api/mail/bulk-actions    - Bulk actions on emails`);
  console.log(`   POST /api/mail/empty-trash     - Empty trash`);
  console.log(`   POST /api/mail/search          - Search emails`);
  console.log(`   GET  /api/mail/folder-counts   - Get folder counts`);
  console.log(`   POST /api/decrypt              - Decrypt encrypted email`);
  console.log(`   POST /api/verify-token         - Verify JWT token`);
  console.log(`   POST /api/debug/fix-mailids    - Fix duplicate mailIds`);
  console.log(`\n🔐 Encryption Support:`);
  console.log(`   • Standard Email (no encryption)`);
  console.log(`   • Quantum OTP (One-Time Pad)`);
  console.log(`   • Quantum AES-256-GCM`);
  console.log(`\n✅ CRITICAL FIXES APPLIED:`);
  console.log(`   • Same mailId for sender & receiver copies`);
  console.log(`   • Enhanced security information in email responses`);
  console.log(`   • Stable email status updates`);
  console.log(`========================================\n`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('🔄 SIGTERM received. Shutting down gracefully...');
  server.close(() => {
    console.log('👋 Server closed');
    mongoose.connection.close();
    process.exit(0);
  });
});

process.on('SIGINT', () => {
  console.log('🔄 SIGINT received. Shutting down gracefully...');
  server.close(() => {
    console.log('👋 Server closed');
    mongoose.connection.close();
    process.exit(0);
  });
});