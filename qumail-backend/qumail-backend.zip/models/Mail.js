// models/Mail.js - SIMPLIFIED VERSION
const mongoose = require('mongoose');

const MailSchema = new mongoose.Schema({
  mailId: {
    type: String,
    required: true,
  },

  from: {
    type: String,
    required: true,
    lowercase: true,
    trim: true
  },

  to: {
    type: String,
    required: true,
    lowercase: true,
    trim: true
  },

  subject: {
    type: String,
    required: true,
    default: "(No Subject)"
  },

  body: {
    type: String,
    required: true
  },

  encryption: {
    type: String,
    enum: ["NONE", "OTP", "AES"],
    default: "NONE"
  },

  // 🔐 AES (backend-only)
  aesKey: {
    type: String,
    default: null
  },

  aesIV: {
    type: String,
    default: null
  },

  folder: {
    type: String,
    enum: ["INBOX", "SENT", "ARCHIVE", "DRAFTS"],
    required: true,
    default: "INBOX"
  },

  owner: {
    type: String,
    required: true,
    lowercase: true,
    trim: true
  },

  read: {
    type: Boolean,
    default: false
  },

  starred: {
    type: Boolean,
    default: false
  },

  important: {
    type: Boolean,
    default: false
  },

  trash: {
    type: Boolean,
    default: false
  },

  snoozed: {
    type: Date,
    default: null
  },

  labels: [{
    type: String,
    default: []
  }],

  createdAt: {
    type: Date,
    default: Date.now
  },

  updatedAt: {
    type: Date,
    default: Date.now
  },

  isDeleted: {
  type: Boolean,
  default: false,
},

deletedAt: {
  type: Date,
  default: null,
},

  sender: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    recipient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    subject: {
      type: String,
      default: "",
    },
    body: {
      type: String,
      default: "",
    },
    isDraft: {
      type: Boolean,
      default: false,
    },
    isDeleted: {
      type: Boolean,
      default: false,
    },
    sentAt: {
      type: Date,
    },
  },
  { timestamps: true 
});

// CRITICAL: Compound unique index for mailId + owner
// Don't specify a name, let MongoDB auto-generate it
MailSchema.index({ mailId: 1, owner: 1 }, { unique: true });

// Performance indexes
MailSchema.index({ owner: 1, folder: 1, trash: 1, createdAt: -1 });
MailSchema.index({ owner: 1, starred: 1 });
MailSchema.index({ owner: 1, important: 1 });
MailSchema.index({ owner: 1, read: 1 });

MailSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model("Mail", MailSchema);