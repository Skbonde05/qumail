const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
  name: String,
  email: { type: String, unique: true },
  password: String,

   settings: {
    emailNotifications: Boolean,
    autoSaveDrafts: Boolean,
    signature: String,
    twoFactorEnabled: Boolean,
    timezone: String
  }
});

module.exports = mongoose.model("User", UserSchema);
