import React, { useEffect, useState } from "react";
import axios from "axios";

function Trash() {
  const [mails, setMails] = useState([]);

  useEffect(() => {
    fetchTrash();
  }, []);

  const fetchTrash = async () => {
    const res = await axios.get("/api/mail/trash");
    setMails(res.data);
  };

  const restore = async (id) => {
    await axios.put(`/api/mail/restore/${id}`);
    fetchTrash();
  };

  const deleteForever = async (id) => {
    await axios.delete(`/api/mail/permanent/${id}`);
    fetchTrash();
  };

  return (
    <div>
      <h2>Trash</h2>
      {mails.map((mail) => (
        <div key={mail._id}>
          <h4>{mail.subject}</h4>
          <button onClick={() => restore(mail._id)}>Restore</button>
          <button onClick={() => deleteForever(mail._id)}>
            Delete Forever
          </button>
        </div>
      ))}
    </div>
  );
}

export default Trash;