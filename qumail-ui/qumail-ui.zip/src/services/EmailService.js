// EmailService.js - UPDATED to match your QuMail backend server
const API_BASE = "http://localhost:5000/api";

// Helper function to get auth headers
const getAuthHeaders = () => {
  const token = localStorage.getItem('token');
  return {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  };
};

class EmailService {
  // ✅ Get user profile and email counts
  static async getProfile() {
    try {
      console.log("👤 Getting user profile...");
      
      const response = await fetch(`${API_BASE}/profile`, {
        method: "GET",
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Profile error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Profile loaded for: ${data.user.email}`);
        return data;
      }
      
      throw new Error(data.message || 'Failed to get profile');
      
    } catch (error) {
      console.error("Get profile error:", error.message);
      throw error;
    }
  }

  // ✅ Get inbox emails
  static async getInboxEmails(limit = 50, page = 1) {
    try {
      console.log(`📥 Fetching inbox emails, page: ${page}, limit: ${limit}`);
      
      const response = await fetch(`${API_BASE}/mail/inbox`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ limit, page })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Inbox error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Got ${data.emails.length} inbox emails (total: ${data.total})`);
        return data;
      }
      
      throw new Error(data.message || 'Failed to get inbox emails');
      
    } catch (error) {
      console.error("Get inbox error:", error.message);
      throw error;
    }
  }

  // ✅ Get sent emails
  static async getSentEmails(limit = 50, page = 1) {
    try {
      console.log(`📤 Fetching sent emails, page: ${page}, limit: ${limit}`);
      
      const response = await fetch(`${API_BASE}/mail/sent`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ limit, page })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Sent error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Got ${data.emails.length} sent emails (total: ${data.total})`);
        return data;
      }
      
      throw new Error(data.message || 'Failed to get sent emails');
      
    } catch (error) {
      console.error("Get sent error:", error.message);
      throw error;
    }
  }

  // ✅ Get archive emails
  static async getArchiveEmails(limit = 50, page = 1) {
    try {
      console.log(`📁 Fetching archive emails, page: ${page}, limit: ${limit}`);
      
      const response = await fetch(`${API_BASE}/mail/archive`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ limit, page })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Archive error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Got ${data.emails.length} archive emails (total: ${data.total})`);
        return data;
      }
      
      throw new Error(data.message || 'Failed to get archive emails');
      
    } catch (error) {
      console.error("Get archive error:", error.message);
      throw error;
    }
  }

  // ✅ Get trash emails
  static async getTrashEmails(limit = 50, page = 1) {
    try {
      console.log(`🗑️ Fetching trash emails, page: ${page}, limit: ${limit}`);
      
      const response = await fetch(`${API_BASE}/mail/trash`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ limit, page })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Trash error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Got ${data.emails.length} trash emails (total: ${data.total})`);
        return data;
      }
      
      throw new Error(data.message || 'Failed to get trash emails');
      
    } catch (error) {
      console.error("Get trash error:", error.message);
      throw error;
    }
  }

  // ✅ Get starred emails
  static async getStarredEmails(limit = 50, page = 1) {
    try {
      console.log(`⭐ Fetching starred emails, page: ${page}, limit: ${limit}`);
      
      const response = await fetch(`${API_BASE}/mail/starred`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ limit, page })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Starred error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Got ${data.emails.length} starred emails (total: ${data.total})`);
        return data;
      }
      
      throw new Error(data.message || 'Failed to get starred emails');
      
    } catch (error) {
      console.error("Get starred error:", error.message);
      throw error;
    }
  }

  // ✅ Get important emails
  static async getImportantEmails(limit = 50, page = 1) {
    try {
      console.log(`🔴 Fetching important emails, page: ${page}, limit: ${limit}`);
      
      const response = await fetch(`${API_BASE}/mail/important`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ limit, page })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Important error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Got ${data.emails.length} important emails (total: ${data.total})`);
        return data;
      }
      
      throw new Error(data.message || 'Failed to get important emails');
      
    } catch (error) {
      console.error("Get important error:", error.message);
      throw error;
    }
  }

  // ✅ Get emails by folder name
  static async getFolderEmails(folderName, limit = 50, page = 1, filter = null) {
    try {
      console.log(`📁 Fetching ${folderName} emails, page: ${page}, limit: ${limit}`);
      
      const response = await fetch(`${API_BASE}/mail/folder/${folderName}`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ limit, page, filter })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`${folderName} error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Got ${data.emails.length} ${folderName} emails (total: ${data.total})`);
        return data;
      }
      
      throw new Error(data.message || `Failed to get ${folderName} emails`);
      
    } catch (error) {
      console.error(`Get ${folderName} error:`, error.message);
      throw error;
    }
  }

  // ✅ Get single email by ID
  static async getEmailById(emailId) {
    try {
      console.log(`📄 Fetching email: ${emailId}`);
      
      const response = await fetch(`${API_BASE}/mail/${emailId}`, {
        method: "GET",
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Email fetch error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Got email: ${emailId}`);
        return data;
      }
      
      throw new Error(data.message || 'Failed to get email');
      
    } catch (error) {
      console.error("Get email by ID error:", error.message);
      throw error;
    }
  }

  // ✅ MOVE EMAILS TO FOLDER (CORRECTED)
  static async moveEmailsToFolder(emailIds, targetFolder) {
    try {
      console.log(`📂 Moving ${emailIds.length} emails to ${targetFolder}:`, emailIds);
      
      const response = await fetch(`${API_BASE}/mail/move-to-folder`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({
          emailIds: Array.isArray(emailIds) ? emailIds : [emailIds],
          targetFolder: targetFolder.toLowerCase()
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Move error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Move successful: ${data.message}`);
        return data;
      }
      
      console.error('Move failed:', data.message, data.details);
      throw new Error(data.message || 'Failed to move emails');
      
    } catch (error) {
      console.error("Move emails error:", error.message);
      throw error;
    }
  }

  // ✅ Update single email status (star, important, etc.)
  static async updateEmailStatus(emailId, action, folder = null, snoozeDate = null) {
    try {
      console.log(`⚡ Updating email ${emailId} with action: ${action}`);
      
      const body = { action };
      if (folder) body.folder = folder;
      if (snoozeDate) body.snoozeDate = snoozeDate;
      
      const response = await fetch(`${API_BASE}/mail/${emailId}/status`, {
        method: "PUT",
        headers: getAuthHeaders(),
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Status update error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Status update successful: ${data.message}`);
        return data;
      }
      
      console.error('Status update failed:', data.message);
      throw new Error(data.message || 'Failed to update email status');
      
    } catch (error) {
      console.error("Status update error:", error.message);
      throw error;
    }
  }

  // ✅ Batch update emails
  static async batchUpdateEmails(emailIds, action, folder = null) {
    try {
      console.log(`⚡ Batch updating ${emailIds.length} emails with action: ${action}`);
      
      const body = { 
        emailIds: Array.isArray(emailIds) ? emailIds : [emailIds],
        action 
      };
      if (folder) body.folder = folder;
      
      const response = await fetch(`${API_BASE}/mail/batch-update`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Batch update error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Batch update successful: ${data.message}`);
        return data;
      }
      
      console.error('Batch update failed:', data.message);
      throw new Error(data.message || 'Failed to batch update emails');
      
    } catch (error) {
      console.error("Batch update error:", error.message);
      throw error;
    }
  }

  // ✅ Bulk actions on all emails in folder
  static async bulkFolderAction(action, folder = null) {
    try {
      console.log(`⚡ Bulk action: ${action} on folder: ${folder || 'all'}`);
      
      const response = await fetch(`${API_BASE}/mail/bulk-actions`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ action, folder })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Bulk action error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Bulk action successful: ${data.message}`);
        return data;
      }
      
      console.error('Bulk action failed:', data.message);
      throw new Error(data.message || 'Failed to perform bulk action');
      
    } catch (error) {
      console.error("Bulk action error:", error.message);
      throw error;
    }
  }

  // ✅ Empty trash
  static async emptyTrash() {
    try {
      console.log(`🗑️ Emptying trash...`);
      
      const response = await fetch(`${API_BASE}/mail/empty-trash`, {
        method: "POST",
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Empty trash error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Trash emptied: ${data.message}`);
        return data;
      }
      
      console.error('Empty trash failed:', data.message);
      throw new Error(data.message || 'Failed to empty trash');
      
    } catch (error) {
      console.error("Empty trash error:", error.message);
      throw error;
    }
  }

  // ✅ Decrypt email
  static async decryptEmail(emailId, encryptionKey = null) {
    try {
      console.log(`🔓 Decrypting email: ${emailId}`);
      
      const body = { emailId };
      if (encryptionKey) body.encryptionKey = encryptionKey;
      
      const response = await fetch(`${API_BASE}/decrypt`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Decrypt error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Decryption successful for email: ${emailId}`);
        return data;
      }
      
      console.error('Decryption failed:', data.message);
      throw new Error(data.message || 'Failed to decrypt email');
      
    } catch (error) {
      console.error("Decrypt email error:", error.message);
      throw error;
    }
  }

  // ✅ Search emails
  static async searchEmails(query, folder = null, limit = 50) {
    try {
      console.log(`🔍 Searching emails: "${query}" in folder: ${folder || 'all'}`);
      
      const response = await fetch(`${API_BASE}/mail/search`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ query, folder, limit })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Search error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Search found ${data.emails.length} emails`);
        return data;
      }
      
      console.error('Search failed:', data.message);
      throw new Error(data.message || 'Failed to search emails');
      
    } catch (error) {
      console.error("Search emails error:", error.message);
      throw error;
    }
  }

  // ✅ Get folder counts
  static async getFolderCounts() {
    try {
      console.log(`📊 Getting folder counts...`);
      
      const response = await fetch(`${API_BASE}/mail/folder-counts`, {
        method: "GET",
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Folder counts error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Got folder counts`);
        return data;
      }
      
      console.error('Get folder counts failed:', data.message);
      throw new Error(data.message || 'Failed to get folder counts');
      
    } catch (error) {
      console.error("Get folder counts error:", error.message);
      throw error;
    }
  }

  // ✅ Send email
  static async sendEmail(to, subject, body, encryptionLevel = 'none') {
    try {
      console.log(`📤 Sending email to: ${to} with encryption: ${encryptionLevel}`);
      
      const response = await fetch(`${API_BASE}/send`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ 
          to, 
          subject: subject || '(No Subject)', 
          body,
          encryptionLevel 
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Send error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Email sent successfully: ${data.messageId}`);
        return data;
      }
      
      console.error('Send email failed:', data.message);
      throw new Error(data.message || 'Failed to send email');
      
    } catch (error) {
      console.error("Send email error:", error.message);
      throw error;
    }
  }

  // ✅ Update user profile
  static async updateProfile(name, settings) {
    try {
      console.log(`📝 Updating profile...`);
      
      const body = {};
      if (name) body.name = name;
      if (settings) body.settings = settings;
      
      const response = await fetch(`${API_BASE}/profile`, {
        method: "PUT",
        headers: getAuthHeaders(),
        body: JSON.stringify(body)
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Profile update error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Profile updated: ${data.message}`);
        return data;
      }
      
      console.error('Profile update failed:', data.message);
      throw new Error(data.message || 'Failed to update profile');
      
    } catch (error) {
      console.error("Update profile error:", error.message);
      throw error;
    }
  }

  // ✅ Change password
  static async changePassword(currentPassword, newPassword, confirmPassword) {
    try {
      console.log(`🔐 Changing password...`);
      
      const response = await fetch(`${API_BASE}/change-password`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ currentPassword, newPassword, confirmPassword })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Change password error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Password changed: ${data.message}`);
        return data;
      }
      
      console.error('Change password failed:', data.message);
      throw new Error(data.message || 'Failed to change password');
      
    } catch (error) {
      console.error("Change password error:", error.message);
      throw error;
    }
  }

  // ✅ Upload avatar
  static async uploadAvatar(avatarData) {
    try {
      console.log(`📷 Uploading avatar...`);
      
      const response = await fetch(`${API_BASE}/upload-avatar`, {
        method: "POST",
        headers: getAuthHeaders(),
        body: JSON.stringify({ avatar: avatarData })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Upload avatar error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Avatar uploaded: ${data.message}`);
        return data;
      }
      
      console.error('Upload avatar failed:', data.message);
      throw new Error(data.message || 'Failed to upload avatar');
      
    } catch (error) {
      console.error("Upload avatar error:", error.message);
      throw error;
    }
  }

  // ✅ Delete avatar
  static async deleteAvatar() {
    try {
      console.log(`🗑️ Deleting avatar...`);
      
      const response = await fetch(`${API_BASE}/avatar`, {
        method: "DELETE",
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error(`Delete avatar error ${response.status}:`, errorText);
        throw new Error(`Server error: ${response.status}`);
      }

      const data = await response.json();
      
      if (data.success) {
        console.log(`✅ Avatar deleted: ${data.message}`);
        return data;
      }
      
      console.error('Delete avatar failed:', data.message);
      throw new Error(data.message || 'Failed to delete avatar');
      
    } catch (error) {
      console.error("Delete avatar error:", error.message);
      throw error;
    }
  }

  // ✅ Verify token
  static async verifyToken() {
    try {
      const response = await fetch(`${API_BASE}/verify-token`, {
        method: "POST",
        headers: getAuthHeaders()
      });

      if (!response.ok) {
        throw new Error('Token verification failed');
      }

      const data = await response.json();
      return data;
      
    } catch (error) {
      console.error("Verify token error:", error.message);
      throw error;
    }
  }

  // ✅ Test connection
  static async testConnection() {
    try {
      const response = await fetch(`${API_BASE}/health`, {
        method: "GET"
      });
      
      if (!response.ok) {
        throw new Error('Server not responding');
      }
      
      const data = await response.json();
      return data.success === true;
    } catch (error) {
      console.error("Test connection error:", error.message);
      return false;
    }
  }

  // ✅ For compatibility with your App.js - fetches all emails from all folders
  static async fetchAllEmails() {
    try {
      console.log("🔍 Fetching all emails...");
      
      // Get folder counts first
      const countsData = await this.getFolderCounts();
      if (!countsData.success) {
        throw new Error('Failed to get folder counts');
      }
      
      const counts = countsData.counts;
      let allEmails = [];
      
      // Fetch emails from each folder that has emails
      const fetchPromises = [];
      
      if (counts.inbox > 0) {
        fetchPromises.push(
          this.getInboxEmails(counts.inbox, 1)
            .then(data => data.emails)
            .catch(err => {
              console.warn('Failed to fetch inbox:', err.message);
              return [];
            })
        );
      }
      
      if (counts.sent > 0) {
        fetchPromises.push(
          this.getSentEmails(counts.sent, 1)
            .then(data => data.emails)
            .catch(err => {
              console.warn('Failed to fetch sent:', err.message);
              return [];
            })
        );
      }
      
      if (counts.archive > 0) {
        fetchPromises.push(
          this.getArchiveEmails(counts.archive, 1)
            .then(data => data.emails)
            .catch(err => {
              console.warn('Failed to fetch archive:', err.message);
              return [];
            })
        );
      }
      
      if (counts.trash > 0) {
        fetchPromises.push(
          this.getTrashEmails(counts.trash, 1)
            .then(data => data.emails)
            .catch(err => {
              console.warn('Failed to fetch trash:', err.message);
              return [];
            })
        );
      }
      
      if (counts.starred > 0) {
        fetchPromises.push(
          this.getStarredEmails(counts.starred, 1)
            .then(data => data.emails)
            .catch(err => {
              console.warn('Failed to fetch starred:', err.message);
              return [];
            })
        );
      }
      
      if (counts.important > 0) {
        fetchPromises.push(
          this.getImportantEmails(counts.important, 1)
            .then(data => data.emails)
            .catch(err => {
              console.warn('Failed to fetch important:', err.message);
              return [];
            })
        );
      }
      
      // Wait for all fetches to complete
      const results = await Promise.all(fetchPromises);
      
      // Combine all emails
      results.forEach(emails => {
        allEmails = allEmails.concat(emails);
      });
      
      console.log(`✅ Total emails fetched: ${allEmails.length}`);
      return allEmails;
      
    } catch (error) {
      console.error("Fetch all emails error:", error.message);
      throw error;
    }
  }

  // ✅ For compatibility with your old App.js
  static async tryFetchEmails() {
    return await this.fetchAllEmails();
  }
}

export default EmailService;