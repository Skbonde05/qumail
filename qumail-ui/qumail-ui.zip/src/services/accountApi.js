import axios from "axios";

const API_URL = process.env.REACT_APP_API_URL || "http://localhost:5000/api";

const api = axios.create({
  baseURL: API_URL,
  headers: {
    "Content-Type": "application/json"
  }
});

// Attach JWT automatically
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("qumail_token");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

/**
 * 👤 Get logged-in user profile
 */
export const getProfile = async () => {
  const res = await api.get("/profile");
  return res.data.user;
};

/**
 * ✏️ Update profile info
 */
export const updateProfile = async (data) => {
  const res = await api.post("/profile/update", data);
  return res.data;
};

/**
 * ⚙️ Update user settings
 */
export const updateSettings = async (settings) => {
  const res = await api.post("/profile/settings", { settings });
  return res.data;
};

/**
 * 🔑 Change password
 */
export const changePassword = async (payload) => {
  const res = await api.post("/profile/change-password", payload);
  return res.data;
};
